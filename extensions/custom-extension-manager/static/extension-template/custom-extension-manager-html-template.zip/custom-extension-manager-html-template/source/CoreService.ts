import packageJSON from '../package.json';
import { showLog, showWarn, showError, waitTime } from './Utils';

export function afterReload() {
    // 在這裡實作插件被重新載入後的邏輯
    showLog('afterReload');
}

// ------------------------------------------------
// 示例方法區塊

export function getRandomNumber(): number {
    const random = Math.floor(Math.random() * 100) + 1;
    return random;
}

// 上方為示例方法，不需要時可刪除
// ------------------------------------------------
// 往下加入插件的業務邏輯程式碼