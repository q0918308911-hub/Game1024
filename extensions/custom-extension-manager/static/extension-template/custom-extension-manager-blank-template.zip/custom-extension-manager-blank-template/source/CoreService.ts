import { AssetInfo } from "@cocos/creator-types/editor/packages/asset-db/@types/public";
import { showLog, showWarn, showError, waitTime } from './Utils';
const packageJSON = require('../package.json');

export function afterReload() {
    // 在這裡實作插件被重新載入後的邏輯
    showLog('afterReload');
}

export function myAssetMenuEvent(assetInfo: AssetInfo, arg: any) {
    // 在這裡處理點擊右鍵菜單選項後的事件
    showLog('myAssetMenuEvent');
}

// 示例: 執行會與場景交互的方法
export async function executeSceneFunction() {
    // 會傳給場景方法的參數
    const args: any[] = [];
    // 場景方法的回傳值
    const executeResult = await Editor.Message.request('scene', 'execute-scene-script', {
        name: packageJSON.name,
        method: 'mySceneFunction', // 注意: 必須對應 SceneScript.ts 中的 method 名稱
        args: args
    });
}

// 上方為示例方法，不需要時可刪除
// ------------------------------------------------
// 往下加入插件的業務邏輯程式碼
