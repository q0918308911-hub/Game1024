import { AssetInfo } from "@cocos/creator-types/editor/packages/asset-db/@types/public";
const packageJSON = require('../package.json');

export function onAssetMenu(assetInfo: AssetInfo) {
    const exampleArg = 'hello world';
    // 在 assets 的 Game 資料夾底下所有資源新增一個右鍵菜單選項
    if (assetInfo.url.startsWith('db://assets/Game/')) {
        return [
            {
                label: '遊戲資源右鍵菜單選項',
                click: () => {
                    // 就算事件出去後只是透過 main.ts 調用 CoreService，也建議透過 message 事件，程式才會轉移到主進程執行
                    // 不建議直接在這邊調用 CoreService
                    Editor.Message.send(packageJSON.name, 'my-asset-menu-event', assetInfo, exampleArg);
                }
            }
        ]
    }

    return [];
}