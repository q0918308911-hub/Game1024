import { join } from 'path';
module.paths.push(join(Editor.App.path, 'node_modules'));
import { Component, director, Node } from "cc";

export const methods: { [key: string]: (...any: any) => any } = {
    mySceneFunction() {
        // 在這裡實作會和場景交互的方法
        // 可以像寫遊戲腳本一樣直接調用 cc 的 API
    },
};